package com.acadgild.googlesearch;

import android.content.Intent;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);//Setting up the main page
        //Defining two Buttons and setting onClickListner
        Button Search=(Button)findViewById(R.id.button);
        Search.setOnClickListener(this);
        Button Clear=(Button)findViewById(R.id.button1);
        Clear.setOnClickListener(this);

    }

    @Override
    public void onClick(View v) {
        //selecting case based on Button id
        switch(v.getId())
        {
            case R.id.button:
                //query for google seacrch
                String searchText="https://www.google.co.in/search?q=";
                EditText Text=(EditText)findViewById(R.id.text);
                searchText=searchText+Text.getText();//joinig the whole query
                //Creating Intent to pass the searchText and open the Browser page
                Intent Search=new Intent(Intent.ACTION_VIEW, Uri.parse(searchText));
                //Starting Intent
                startActivity(Search);

            case R.id.button1:
                EditText Text1=(EditText)findViewById(R.id.text);
                Text1.setText("");//Clearing EditText

        }
    }
}
